﻿using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.EventArg
{
    public class WebSiteAddedEventArgs : EventArgs
    {
        public WebSiteAddedEventArgs (WebSite newWebSite)
	    {
            this.NewWebSite = newWebSite;
	    }

        public WebSite NewWebSite { get; private set; }
    }
}