﻿using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.EventArg
{
    public class MailAddedEventArgs : EventArgs
    {
        public MailAddedEventArgs(Mail newMail)
        {
            NewMail = newMail;
        }

        public Mail NewMail { get; private set; }
    }
}
