﻿using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.EventArg
{
    public class RegistryAddedEventArgs : EventArgs
    {
        public RegistryAddedEventArgs(Registry newRegistry)
        {
            NewRegistry = newRegistry;
        }

        public Registry NewRegistry { get; private set; }
    }
}
