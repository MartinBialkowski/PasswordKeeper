﻿using System;
using System.Collections.Generic;
using System.Linq;
using Entity;
using System.Data.Entity;

namespace DataAccessLayer
{
    public class PasswordDAO : DAO, IGenericRepository<Password>
    {
        public IEnumerable<Password> GetAll()
        {
            return context.Password;
        }

        public Password GetById(int id)
        {
            return context.Password.FirstOrDefault(p => p.id == id);
        }

        public void Insert(Password element)
        {
            context.Password.Add(element);
        }

        public void Delete(int id)
        {
            Password password = context.Password.Find(id);
            context.Password.Remove(password);
        }

        public void Update(Password element)
        {
            context.Entry(element).State = EntityState.Modified;
        }

        public void Save()
        {
            context.SaveChanges();
        }
    }
}
