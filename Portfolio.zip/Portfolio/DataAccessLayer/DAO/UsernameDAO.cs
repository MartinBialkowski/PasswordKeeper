﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using Entity;

namespace DataAccessLayer
{
    public class UsernameDAO : DAO, IGenericRepository<Username>
    {
        public IEnumerable<Username> GetAll()
        {
            return context.Username;
        }

        public Username GetById(int id)
        {
            return context.Username.FirstOrDefault(u => u.id == id);
        }

        public void Insert(Username element)
        {
            context.Username.Add(element);
        }

        public void Delete(int id)
        {
            Username username = context.Username.Find(id);
            context.Username.Remove(username);
        }

        public void Update(Username element)
        {
            context.Entry(element).State = EntityState.Modified;
        }

        public void Save()
        {
            context.SaveChanges();
        }
    }
}
