﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using Entity;
using DataAccessLayer.EventArg;

namespace DataAccessLayer
{
    public class RegistryDAO : DAO, IGenericRepository<Registry>
    {
        /// <summary>
        /// Loads all registers from data base.
        /// </summary>
        /// <returns>IEnumerable of registers.</returns>
        public IEnumerable<Registry> GetAll()
        {
            return context.Registry;
        }
        
        /// <summary>
        /// Finds register by specified id.
        /// </summary>
        /// <param name="id">identificator of register.</param>
        /// <returns>First register with specified id;</returns>
        public Registry GetById(int id)
        {
            return context.Registry.FirstOrDefault(r => r.id == id);
        }

        /// <summary>
        /// Places the specified registry into data base.
        /// </summary>
        public void Insert(Registry element)
        {
            context.Registry.Add(element);

            if(RegistryAdded != null)
            {
                RegistryAdded(this, new RegistryAddedEventArgs(element));
            }
        }

        /// <summary>
        /// Removes registry from date base by specified identificator.
        /// </summary>
        public void Delete(int id)
        {
            Registry registry = context.Registry.Find(id);
            context.Registry.Remove(registry);
        }

        /// <summary>
        /// Updates register(not sure if that works).
        /// </summary>
        public void Update(Registry element)
        {
            context.Entry(element).State = EntityState.Modified;
        }

        /// <summary>
        /// Saves context.
        /// </summary>
        public void Save()
        {
            context.SaveChanges();
        }

        /// <summary>
        /// Raised when a registry is placed into date base
        /// </summary>
        public event EventHandler<RegistryAddedEventArgs> RegistryAdded;
    }
}
