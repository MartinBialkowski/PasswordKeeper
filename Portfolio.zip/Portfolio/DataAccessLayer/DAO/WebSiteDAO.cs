﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using Entity;
using DataAccessLayer.EventArg;

namespace DataAccessLayer
{
    public class WebSiteDAO : DAO, IGenericRepository<WebSite>
    {

        public IEnumerable<WebSite> GetAll()
        {
            return context.WebSite;
        }

        public WebSite GetById(int id)
        {
            return context.WebSite.FirstOrDefault(w => w.id == id);
        }

        public void Insert(WebSite element)
        {
            context.WebSite.Add(element);
        }

        public void Delete(int id)
        {
            WebSite website = context.WebSite.Find(id);
            context.WebSite.Remove(website);
        }

        public void Update(WebSite element)
        {
            context.Entry(element).State = EntityState.Modified;
        }

        public void Save()
        {
            context.SaveChanges();
        }

        /// <summary>
        /// Raised when a web service is placed into date base
        /// </summary>
        public EventHandler<WebSiteAddedEventArgs> WebSiteAdded;
    }
}
