﻿using System;
using System.Collections.Generic;
using Entity;

namespace DataAccessLayer
{
    public class DAO
    {
        protected PasswordKeeperEntities context;

        public DAO()
        {
            context = DBConnection.Context;
        }

        //public void Save()
        //{
        //    context.SaveChanges();
        //}
    }
}
