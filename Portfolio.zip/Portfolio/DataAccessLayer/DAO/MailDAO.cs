﻿using DataAccessLayer.EventArg;
using Entity;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace DataAccessLayer
{
    public class MailDAO : DAO, IGenericRepository<Mail>
    {
        public IEnumerable<Mail> GetAll()
        {
            return context.Mail;
        }

        public Mail GetById(int id)
        {
            return context.Mail.FirstOrDefault(m => m.id == id);
        }

        public void Insert(Mail element)
        {
            context.Mail.Add(element);

            if(MailAdded != null)
            {
                MailAdded(this, new MailAddedEventArgs(element));
            }
        }

        public void Delete(int id)
        {
            Mail mail = context.Mail.Find(id);
            context.Mail.Remove(mail);
        }

        public void Update(Mail element)
        {
            context.Entry(element).State = EntityState.Modified;
        }

        public void Save()
        {
            context.SaveChanges();
        }

        /// <summary>
        /// Raised when a e-mail address is placed into date base
        /// </summary>
        public EventHandler<MailAddedEventArgs> MailAdded;
    }
}
