﻿using Entity;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public class CategoryDAO : DAO, IGenericRepository<Category>
    {
        public IEnumerable<Category> GetAll()
        {
            return context.Category;
        }

        public Category GetById(int id)
        {
            return context.Category.FirstOrDefault(c => c.id == id);
        }

        public void Insert(Category element)
        {
            context.Category.Add(element);
        }

        public void Delete(int id)
        {
            Category category = context.Category.Find(id);
            context.Category.Remove(category);
        }

        public void Update(Category element)
        {
            context.Entry(element).State = EntityState.Modified;
        }
        
        public void Save()
        {
            context.SaveChanges();
        }
    }
}
