﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PasswordsKeeper
{
    public class UserNotificationMessage
    {
        public string Message { get; private set; }
        public int Seconds { get; private set; }

        public UserNotificationMessage(string message, int seconds)
        {
            Message = message;
            Seconds = seconds;
        }
    }
}
